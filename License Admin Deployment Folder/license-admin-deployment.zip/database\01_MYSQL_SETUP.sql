-- ============================================
-- HisaabKitab License Admin System
-- MySQL Database Setup Script
-- ============================================
-- 
-- This script creates the complete MySQL database schema
-- Run this in MySQL (phpMyAdmin or MySQL command line)
--
-- INSTRUCTIONS:
-- 1. Create database: CREATE DATABASE license_admin;
-- 2. Select database: USE license_admin;
-- 3. Run this entire script
-- 4. That's it! Everything will be set up automatically
--
-- ============================================

-- Create database if not exists
CREATE DATABASE IF NOT EXISTS license_admin CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE license_admin;

-- ============================================
-- STEP 1: CREATE TABLES
-- ============================================

-- AdminUsers Table
CREATE TABLE IF NOT EXISTS AdminUsers (
    id VARCHAR(36) PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    passwordHash VARCHAR(255) NOT NULL,
    role ENUM('superadmin', 'admin') DEFAULT 'admin',
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Licenses Table
CREATE TABLE IF NOT EXISTS Licenses (
    id VARCHAR(36) PRIMARY KEY,
    licenseKey VARCHAR(50) UNIQUE NOT NULL,
    tenantName VARCHAR(100) NOT NULL,
    plan VARCHAR(50) NULL,
    maxDevices INT DEFAULT 1 CHECK (maxDevices > 0),
    maxUsers INT DEFAULT 1 CHECK (maxUsers > 0),
    features JSON DEFAULT (JSON_OBJECT()),
    startDate DATE NULL,
    expiryDate DATE NOT NULL,
    status ENUM('active', 'expired', 'revoked', 'suspended') DEFAULT 'active',
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_license_key (licenseKey),
    INDEX idx_status (status),
    INDEX idx_expiry_date (expiryDate)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Activations Table
CREATE TABLE IF NOT EXISTS Activations (
    id VARCHAR(36) PRIMARY KEY,
    licenseId VARCHAR(36) NOT NULL,
    deviceId VARCHAR(100) NOT NULL,
    activatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    lastCheck TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status ENUM('active', 'blocked', 'revoked') DEFAULT 'active',
    FOREIGN KEY (licenseId) REFERENCES Licenses(id) ON DELETE CASCADE,
    UNIQUE KEY unique_license_device (licenseId, deviceId),
    INDEX idx_license_id (licenseId),
    INDEX idx_device_id (deviceId),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- AuditLogs Table
CREATE TABLE IF NOT EXISTS AuditLogs (
    id VARCHAR(36) PRIMARY KEY,
    licenseId VARCHAR(36) NULL,
    action VARCHAR(50) NOT NULL,
    details JSON NULL,
    ipAddress VARCHAR(45) NULL,
    userAgent TEXT NULL,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (licenseId) REFERENCES Licenses(id) ON DELETE SET NULL,
    INDEX idx_license_id (licenseId),
    INDEX idx_action (action),
    INDEX idx_created_at (createdAt)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- STEP 2: INSERT INITIAL ADMIN USER
-- ============================================
-- Default password: admin123
-- Hash: $2a$10$xhtMPoXvD3oM1q0Mb98tIe54iB2fv67D14Dl9GXTpkDmfFKawcuf2
-- ⚠️ CHANGE THIS PASSWORD IMMEDIATELY AFTER FIRST LOGIN!

INSERT INTO AdminUsers (id, username, passwordHash, role, createdAt, updatedAt)
VALUES (
    UUID(),
    'superadmin',
    '$2a$10$xhtMPoXvD3oM1q0Mb98tIe54iB2fv67D14Dl9GXTpkDmfFKawcuf2',
    'superadmin',
    CURRENT_TIMESTAMP,
    CURRENT_TIMESTAMP
) ON DUPLICATE KEY UPDATE 
    passwordHash = VALUES(passwordHash),
    role = VALUES(role);

-- ============================================
-- STEP 3: VERIFY SETUP
-- ============================================

SELECT 'Database setup completed successfully!' AS Status;
SELECT COUNT(*) AS AdminUsersCount FROM AdminUsers;
SELECT COUNT(*) AS TablesCount FROM information_schema.tables WHERE table_schema = 'license_admin';

